# Kristendomens hemlighet – Escape Room

Ett webbaserat escape room med 32 frågor om kristendomen.

## Funktioner
- 32 frågor med låsta dörrar
- Jumpscare med ett läskigt monsteransikte när du svarar fel (utan grafiskt innehåll)
- "YAYYYY!"-skärm och segerljud när du svarar rätt
- Läskig bakgrundsambience som startas med knappen högst upp (webbläsare kräver klick innan ljud får spelas)
- Framstegsmätare och poäng

## Spela lokalt
Öppna `index.html` i en webbläsare.

## Publicera gratis med GitHub Pages
1. Skapa ett nytt repository på GitHub.
2. Ladda upp `index.html` till repositoryts rotmapp.
3. Öppna **Settings → Pages**.
4. Under **Build and deployment**, välj **Deploy from a branch**.
5. Välj branch **main** och mapp **/(root)**. Klicka **Save**.
6. Efter någon minut finns spelet på `https://DITT-ANVÄNDARNAMN.github.io/REPOSITORY-NAMN/`.

Spelet är fristående och använder inga externa bibliotek. Ljuden skapas i webbläsaren och bakgrundsljudet startar först när spelaren trycker på musikknappen.
